import java.awt.Button;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Shop2014302580369 {
	public  static void main(String[] args){
	JFrame jf=new JFrame("宠物商店页面");
	JLabel lbl1=new JLabel("宠物商店购买");
	JLabel lbl2=new JLabel("猫");
	JTextField jtf=new JTextField();
	JLabel lbl3=new JLabel("狗");
	JPasswordField jpf=new JPasswordField();
	lbl1.setSize(100,100);
	lbl2.setSize(50,100);
	lbl3.setSize(50,100);
	lbl1.setLocation(270,10);
	lbl2.setLocation(100,100);
	lbl3.setLocation(100,200);
	jtf.setSize(200,30);
	jtf.setLocation(150,135);
	jpf.setSize(200,30);
	jpf.setLocation(150,235);
	jf.add(lbl1);
	jf.add(lbl2);
	jf.add(lbl3);
	jf.add(jtf);
	jf.add(jpf);
	
	jf.setSize(600,400);
	
	JPanel p3=new JPanel();
    JButton bt1=new JButton("购买"); 
   
    p3.setSize(100,100);
    p3.setLocation(400,130);
    jf.setLayout(null);
    jf.add(p3);
    p3.add(bt1);
    
    JPanel p4=new JPanel();
    Button bt2=new Button("购买"); 
   
    p4.setSize(100,100);
    p4.setLocation(400,230);
    jf.setLayout(null);
    jf.add(p4);
    p4.add(bt2);
    
    jf.setResizable(false);
    jf.setVisible(true);
    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}