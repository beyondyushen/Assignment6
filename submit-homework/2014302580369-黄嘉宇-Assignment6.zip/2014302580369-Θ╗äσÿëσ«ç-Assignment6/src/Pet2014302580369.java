
public class Pet2014302580369 {
	private int PetId;
	private String PetName;
	private int PetPrice;
	private String PetFunction;
	private int PetLifetime;
	public int getId(){
		return PetId;
	}
	public void setId(int PetId){
		this.PetId = PetId;
	}
	public String getName(){
		return PetName;
	}
	public void setName(String PetName){
		this.PetName = PetName;
	}
	public int getPrice(){
		return PetPrice;
	}
	public void setPrice(int PetPrice){
		this.PetPrice = PetPrice;
	}
	public String getFunction(){
		return PetFunction;
	}
	public void setFunction(String PetFunction){
		this.PetFunction = PetFunction;
	}
	public int getLifetime(){
		return PetLifetime;
	}
	public void setLifetime(int PetLifeTime){
		this.PetLifetime =  PetLifeTime;
	}
	public void Pet(int PetId,String PetName,int PetPrice,String PetFunction,int PetLifetime){
		this.PetId=PetId;
		this.PetName=PetName;
		this.PetPrice=PetPrice;
        this.PetFunction=PetFunction;
        this.PetLifetime=PetLifetime;
	}
	
}

