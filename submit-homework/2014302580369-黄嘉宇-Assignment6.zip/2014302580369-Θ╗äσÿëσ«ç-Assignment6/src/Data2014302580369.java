import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class Data2014302580369 {
 public Connection getConn()
 {
  Connection conn=null;
  try {
   Class.forName("com.mysql.jdbc.Driver");
  } catch (ClassNotFoundException e) {
   e.printStackTrace();
  }
  String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
  try {
   conn=DriverManager.getConnection(url, "root", "");
  } catch (SQLException e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  }  
  return conn;
 }
 public void closeAll(ResultSet rs,Statement stat,Connection conn)
 {
  if(rs!=null)
   try {
    rs.close();
   } catch (SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
  if(stat!=null)
   try {
    stat.close();
   } catch (SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
  if(conn!=null)
   try {
    conn.close();
   } catch (SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
 }
}