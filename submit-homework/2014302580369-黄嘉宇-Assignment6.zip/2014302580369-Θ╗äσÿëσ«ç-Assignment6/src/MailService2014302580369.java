package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public  class MailService2014302580369 implements IMailService{
	private Session sess;
	private Message mess;
	private Authenticator auth;
	private Properties prop;
	private String content;
	private String username="13006191550@163.com";
	private String password="crzlfhznlvjponar";
	/**
     * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
     */
	@Override
	public void connect() throws MessagingException{
		prop=new Properties();
		prop.put("mail.smtp.auth", true);	   
	    prop.put("mail.smtp.host", "smtp.163.com");
	    prop.put("mail.imap.host", "imap.163.com"); 
	    auth= new Authenticator() {
	           protected PasswordAuthentication getPasswordAuthentication() {
	               return new PasswordAuthentication(username, password);
	           }
	    };
	    sess = Session.getInstance(prop, auth);
	    System.out.print("connect sucessful\n");
	}
	/**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException{
		mess=new MimeMessage(sess);
    	mess.setFrom(new InternetAddress(username));
    	mess.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
    	mess.setSubject(subject);
    	mess.setContent(content, "text/html");
        Transport.send(mess);
	}
	/**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	@Override
	public boolean listen() throws MessagingException{
		Store st = sess.getStore("imap");
    	st.connect("imap.163.com",username,password);
    	Folder fol = st.getFolder("INBOX");
    	fol.open(Folder.READ_ONLY);
    	if(fol.getNewMessageCount() > 0){
    		fol.close(false);
        	st.close();
			return true;
		}else{
			fol.close(false);
        	st.close();
			return false;
		}	
	}
	/**
     * 接收自动回复的内容，并转换为字符串
     * 注：用你能想到的任意方法寻找回复邮件均可，并不一定要用到这两个参数
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException{
       	Store st = sess.getStore("imap");
    	st.connect();
    	Folder fol = st.getFolder("INBOX");
    	fol.open(Folder.READ_ONLY);
    	mess=fol.getMessage(fol.getMessages().length);
    	content ="主题: "+subject+"\n"+"来自: "+sender+"\n"+"内容： "+mess.getContent();
    	fol.close(false);
    	st.close();
    	return content;	
	}
}